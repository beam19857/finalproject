package backend.dicovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DicoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
