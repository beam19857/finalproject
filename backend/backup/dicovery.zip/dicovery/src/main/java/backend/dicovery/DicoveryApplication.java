package backend.dicovery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DicoveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(DicoveryApplication.class, args);
	}

}
