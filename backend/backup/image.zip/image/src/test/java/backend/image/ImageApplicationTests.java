package backend.image;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageApplicationTests {

	@Test
	void contextLoads() {
	}

}
